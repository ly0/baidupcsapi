#!/usr/bin/env python
# -*- coding: utf-8 -*-

__title__ = 'baidupcsapi'
__version__ = '0.1.0'
__author__ = 'mozillazg,latyas'
__license__ = 'MIT'

from .api import PCS