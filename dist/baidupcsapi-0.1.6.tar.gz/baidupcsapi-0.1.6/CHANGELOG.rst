Changelog
=========

0.1.4 (2014-02-06)
-----------------
把文档补全了，修正了一些错误

0.1.3 (2014-02-05)
-----------------
*上传文件支持stream了，添加回调函数接口，在一个片段完成时可以通知回调函数
* 代码片段来自于：

http://foobarnbaz.com/2012/12/31/file-upload-progressbar-in-pyqt/
http://stackoverflow.com/questions/13909900/progress-of-python-requests-post/

0.1.1/0.1.2 忘了
-----------------

0.1.0 (2014-02-04)
-----------------
* 删除了通过pan.baidu.com获取不到的Api
* 新增本地上传种子离线下载
* 新增验证码，终端下可显示
* set_fastest_baidu_server() 可以自动选择最快的pcs服务器
* 可以调用set_pcs_server(server)人工设置服务器
* set_fastest_baidu_server() / set_pcs_server(server) 调用后会在目录下生成.pcs-server，内有函数的调用结果，每次初始化PCS类时会检查是否存在该文件

以下是原作者的CHANGELOG
------------------

0.3.1 (2013-10-25)
------------------

* 上传、下载部分的 api 改用加速域名 c.pcs.baidu.com 和 d.pcs.baidu.com


0.3.0 (2013-09-13)
------------------

* 添加 ``baidupcs.InvalidToken`` 异常


0.2.0 (2013-09-12)
------------------

* 支持 Python 3


0.1.0 (2013-09-09)
------------------

- 第一版，封装了所有文件操作 RESET API.
